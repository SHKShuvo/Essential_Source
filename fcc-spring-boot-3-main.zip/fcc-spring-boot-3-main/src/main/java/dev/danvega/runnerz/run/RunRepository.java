package dev.danvega.runnerz.run;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.ListCrudRepository;

import java.util.List;
import java.util.Optional;

public interface RunRepository extends JpaRepository<Run, Long> {

    //int count();

//    void saveAll(List<Run> runs);
//
//    Optional<Run> findRunByLocation(String location);

}
