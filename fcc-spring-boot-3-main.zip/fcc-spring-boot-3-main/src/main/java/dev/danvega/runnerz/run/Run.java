package dev.danvega.runnerz.run;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Run")
public class Run {
    @Id
    private Long id;
    private String title;
    private LocalDateTime startedOn;
    private LocalDateTime completedOn;
    @Positive
    private Integer miles;
    private Location location;
    @Version
    private Integer version;
}
