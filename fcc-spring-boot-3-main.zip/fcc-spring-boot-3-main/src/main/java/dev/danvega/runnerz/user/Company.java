package dev.danvega.runnerz.user;

public record Company(String name, String catchPhrase, String bs) {

}
