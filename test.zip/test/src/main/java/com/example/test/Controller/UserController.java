package com.example.test.Controller;

import com.example.test.DTO.UserDTO;
import com.example.test.Entity.UserEntity;
import com.example.test.Mapper.UserRequest;
import com.example.test.Procedure.UserInsertProcedure;
import com.example.test.ResponseModel.Parameters;
import com.example.test.ResponseModel.ResponseModel;
import com.example.test.ResponseModel.UserAccessModel;
import com.example.test.Service.UserService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins ="*", allowedHeaders = "*")
@RequestMapping("/gums/v1/user_role")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private UserInsertProcedure userInsertProcedure;

    // Simple Get Request
    @GetMapping("/get")
    public String GetList(){
        String json = "";
        try{
            ArrayList<HashMap<String, String>> dataMap = new ArrayList<HashMap<String, String>>();

            HashMap<String, String> data1 = new HashMap<String, String>();
            data1.put("image", "2130837526");
            data1.put("category", "Chairs");
            data1.put("Quantity", "1");

            HashMap<String, String> data2 = new HashMap<String, String>();
            data2.put("image", "2130837566");
            data2.put("category", "Mirrors");
            data2.put("Quantity", "2");

            dataMap.add(data1);
            dataMap.add(data2);

            ObjectMapper objectMapper = new ObjectMapper();

            json = objectMapper.writeValueAsString(dataMap);

        }catch(Exception e){
            System.out.println("Error Occured");
        }
        return json;
    }

    @GetMapping("/get2")
    public String GetList2(){
        String jsonX = "{ \"color\" : \"Black\", \"type\" : \"FIAT\" }";
        ObjectMapper objectMapper = new ObjectMapper();
        String color="";
        String type="";
        try{
            JsonNode jsonNode = objectMapper.readTree(jsonX);
            color = jsonNode.get("color").asText();
            type = jsonNode.get("type").asText();
            System.out.println(color+"-"+type);
        }catch(Exception e){
            System.out.println("Error Occured");
        }
        return color+"-"+type;
    }

    // Get All Users
    @GetMapping("/users")
    public List<UserEntity> getAllUsers(){
        return userService.getAllUsers();
    }

    @GetMapping("/user")
    public List<UserDTO> getAllUser() {
        return userService.getAllUser();
    }

    // Get User By ID
    @GetMapping("/users/{id}")
    public UserDTO getUserById(@Valid @PathVariable(name = "id") long id){
        return userService.getUserByUserId(id);
    }

    // Save User
    @PostMapping("/save")
    public ResponseModel createNewUser(@Valid @RequestBody UserDTO userDTO){
        return userService.createUser(userDTO);
    }

    @PostMapping("/users/save")
    public ResponseModel createEventWiseFields(@Valid @RequestBody List<UserDTO>
                                                           userDTOList){
        return userService.createMultipleUsers(userDTOList);
    }


    //Update User
    @PutMapping("/users/{id}")
    public ResponseModel updateUser(@Valid @PathVariable(name = "id") long id,
                                            @Valid @RequestBody UserDTO userDTO){
        return userService.updateUser(id, userDTO);
    }

    // Delete User
    @DeleteMapping("/users/{id}")
    public ResponseModel deleteUser(@Valid @PathVariable(name = "id") long id){
        return userService.deleteUser(id);
    }

    // Get Department By Id
    @GetMapping("/query/{deptId}")
    public List<UserAccessModel> getDepartmentById(@PathVariable(name = "deptId")
                                    long deptId) {
        return userService.getDeptById(deptId);
    }

    // Get Menu By Id
    @GetMapping("/menu/{applicationUniqueId}")
    public Object menuTreePopulate( @PathVariable(name = "applicationUniqueId")
                                    long applicationUniqueId) {
        return userService.menuTreePopulate(applicationUniqueId);

    }

    // Make New User Through Procedure
    @RequestMapping(value = "/make-user", method = RequestMethod.POST)
    public ResponseEntity<?> makeNewUser(@RequestBody UserRequest userRequest, HttpServletRequest request) {
        System.out.println("Test ");
        Map<String, Object> info = new HashMap<>();
        Parameters parameters = new Parameters();
        parameters.setActFlg(userRequest.getActFlg());
        parameters.setEmail(userRequest.getEmail());
        parameters.setFirstName(userRequest.getFirstName());
        parameters.setLastName(userRequest.getLastName());
        parameters.setPhone(userRequest.getPhone());


        parameters = userInsertProcedure.MakeUser(parameters);

        if (parameters.getErrorMessage().equals("Success")) {
            info.put("Response Message", parameters.getErrorMessage());
        } else {
            info.put("Response Message", parameters.getErrorMessage());
        }
        return ResponseEntity.ok(info);
    }
}
