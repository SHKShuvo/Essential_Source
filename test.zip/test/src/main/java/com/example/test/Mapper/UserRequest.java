package com.example.test.Mapper;

import lombok.Data;

@Data
public class UserRequest {
    private String actFlg;
    private String email;
    private String firstName;
    private String lastName;
    private String phone;
}
